package client;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import shared.SaludadorInterface;

public class Cliente {
    public static void main(String[] args) 
    {
        try 
        {
            Registry registro = LocateRegistry.getRegistry(1099);
            SaludadorInterface saludador = (SaludadorInterface)registro.lookup("Saludador");
            saludador.diHola();
            System.out.println(saludador.diHola());
        }catch (RemoteException rex)
        {
            System.err.println(rex.getMessage());
        }catch (NotBoundException nbex)
        {
            System.err.println(nbex.getMessage());
        }   
    }
}
